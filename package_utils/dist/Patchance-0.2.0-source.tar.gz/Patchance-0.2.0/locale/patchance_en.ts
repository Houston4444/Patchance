<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>DialogAboutPatchance</name>
    <message>
        <location filename="../resources/ui/about_patchance.ui" line="14"/>
        <source>About Patchance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/about_patchance.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Patchance&lt;/span&gt;&lt;/p&gt;&lt;p&gt;version : %s&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/about_patchance.ui" line="53"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Patchance is a python Qt application to manage JACK connections.&lt;/p&gt;&lt;p&gt;If you want the same patchbay with session management, you can use RaySession instead.&lt;/p&gt;&lt;p&gt;It uses the  HoustonPatchbay submodule for the canvas.&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;right&quot;&gt;Copyright (C) 2022-2022 houston4444&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../resources/ui/main_win.ui" line="14"/>
        <source>Patchance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="63"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="70"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="80"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="111"/>
        <source>Show Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="114"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="123"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="132"/>
        <source>About Patchance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="141"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../resources/ui/main_win.ui" line="150"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
