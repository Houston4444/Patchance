

from patchbay import PatchbayToolsWidget, FilterFrame, PatchGraphicsView
from patchbay.tool_bar import PatchbayToolBar


class JackStatesWidget(PatchbayToolsWidget):
    def __init__(self, parent):
        super().__init__()
        

class PatchFilterFrame(FilterFrame):
    pass

        
class PatchanceGraphicsView(PatchGraphicsView):
    pass


class PatchanceToolBar(PatchbayToolBar):
    pass